# Example: timer_group

This example uses the timer group driver to generate timer interrupts at two specified alarm intervals.
}

```
